# Jest Setup and Configuration Recommendation for Client

**Date:** 2025-05-14

## Overview
The client project currently lacks a Jest setup. To enable robust unit and integration testing for React components and hooks, the following steps are recommended and follow best practices for Vite + React projects as of May 2025:

## 1. Install Required Packages

- `jest` (test runner)
- `@testing-library/react` (React component testing utilities)
- `@testing-library/jest-dom` (custom DOM matchers)
- `@testing-library/user-event` (user interaction simulation)
- `ts-jest` (TypeScript preprocessor for Jest)
- `@types/jest` (TypeScript types for Jest)

## 2. Add Jest Configuration

Create `/client/jest.config.ts` with the following content:

```ts
import type { Config } from 'jest';

const config: Config = {
  preset: 'ts-jest',
  testEnvironment: 'jsdom',
  roots: ['<rootDir>/src'],
  testMatch: ['**/__tests__/**/*.test.(ts|tsx)', '**/?(*.)+(spec|test).[tj]s?(x)'],
  setupFilesAfterEnv: ['<rootDir>/src/__tests__/jest.setup.ts'],
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/$1',
  },
  moduleDirectories: ['node_modules', 'src'],
  collectCoverage: true,
  collectCoverageFrom: ['src/**/*.{ts,tsx}', '!src/__tests__/**', '!src/types/**'],
  coverageDirectory: 'coverage',
  coverageReporters: ['text', 'lcov', 'clover'],
  clearMocks: true,
  resetMocks: true,
  restoreMocks: true,
  // Uncomment if you see ESM transform errors:
  // transformIgnorePatterns: [
  //   '/node_modules/(?!(your-esm-package)/)'
  // ],
};

export default config;
```

## 3. Add Jest Setup File

Create `/client/src/__tests__/jest.setup.ts` with:

```ts
import '@testing-library/jest-dom';
```

## 4. Add Test Script to package.json

In `/client/package.json`, add:

```json
"scripts": {
  "test": "jest --passWithNoTests"
}
```

## 5. Test File Placement

- Place test files in `src/__tests__/` or alongside components as `ComponentName.test.tsx`.

## 6. (Optional) Update README

- Document how to run tests: `npm test` in `/client`.

## 7. Additional Best Practices

- Use `describe`/`it` blocks for test structure.
- Use `beforeEach`/`afterEach` for setup/cleanup.
- Mock network requests and external dependencies.
- Prefer RTL queries by role/text/label over test IDs.
- Use `user-event` for simulating user actions.
- Keep tests isolated and avoid global state.
- Document how to run tests in the README.

---
**This configuration and approach follows current best practices for Jest in Vite + React projects as of May 2025.**
