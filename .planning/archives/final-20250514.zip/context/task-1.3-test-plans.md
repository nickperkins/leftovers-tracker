# Task 1.3: Test Plans for Major Components and Hooks (Colocated)

**Date:** 2025-05-14

## Sources Consulted
- `src/components/` (Dashboard, LeftoverForm, LeftoverDetails, Layout, ThemeProvider)
- `src/hooks/` (useDashboardLogic, useLayoutLogic, useLeftoverDetailsLogic, useLeftoverFormLogic)
- Jest and Testing Library best practices

## Key Findings
- Colocated tests will be used: each component/hook will have a `ComponentName.test.tsx` or `hookName.test.ts` file next to its implementation.
- Test plans will focus on unit/component behavior, user interaction, and integration with context/providers where relevant.

## Test Plan Table
| Target | Test File | Test Focus |
|--------|-----------|------------|
| Dashboard | Dashboard.test.tsx | Rendering, filtering, expiry status, navigation, error/loading states |
| LeftoverForm | LeftoverForm.test.tsx | Form validation, submission, editing, tag/portion/expiry logic |
| LeftoverDetails | LeftoverDetails.test.tsx | Display, consume/delete actions, tag rendering, navigation |
| Layout | Layout.test.tsx | Navigation, theme switching, drawer/menu logic |
| ThemeProvider | ThemeProvider.test.tsx | Theme switching, context, persistence |
| useDashboardLogic | useDashboardLogic.test.ts | Filtering, sorting, derived state |
| useLayoutLogic | useLayoutLogic.test.ts | Drawer/menu state, navigation helpers |
| useLeftoverDetailsLogic | useLeftoverDetailsLogic.test.ts | Data fetching, mutation handling, error states |
| useLeftoverFormLogic | useLeftoverFormLogic.test.ts | Form state, validation, mutation handling |

## Decisions/Assumptions
- Each test file will be colocated with its target (e.g., `Dashboard.test.tsx` in `components/Dashboard/`).
- Tests will use React Testing Library and user-event for user interaction.
- Mock Apollo/network and context as needed for isolation.

## Next Steps
- For each test, write a brief test plan (objectives, scenarios, edge cases) in a comment at the top of the test file before implementation.
- No test code will be written until all test plans are documented and approved.
