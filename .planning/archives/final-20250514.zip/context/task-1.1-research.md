# Task 1.1 Research: Client Code Structure and Key Components

**Date:** 2025-05-14

## Sources Consulted
- `/client/src/App.tsx` (main app entry, routing)
- `/client/src/components/` (UI components)
- `/client/src/hooks/` (custom hooks)
- `/client/src/contexts/` (context providers)
- `/client/src/lib/` (utility and config)
- `/client/README.md` (project info)
- `/client/package.json` (dependencies, scripts)

## Key Findings

### Main Structure
- **App entry:** `App.tsx` sets up routing and providers.
- **Component organization:**
  - `components/` contains UI components, grouped by feature (e.g., `Dashboard`, `LeftoverForm`, `LeftoverDetails`, `Layout`).
  - `hooks/` contains custom hooks for business logic (e.g., `useDashboardLogic`, `useLeftoverFormLogic`).
  - `contexts/` provides React context (e.g., `ColorModeContext`).
  - `lib/` contains Apollo client setup, theme config, and environment utilities.

### Key Components for Testing
- **Dashboard** (`components/Dashboard/`): Main list and filtering of leftovers.
- **LeftoverForm** (`components/LeftoverForm/`): Add/edit leftover items.
- **LeftoverDetails** (`components/LeftoverDetails/`): View and interact with a single leftover.
- **Layout** (`components/Layout/`): App shell, navigation, and theming.
- **ThemeProvider** (`providers/ThemeProvider.tsx`): Theme context and switching.

### Key Hooks for Testing
- `useDashboardLogic.ts`
- `useLayoutLogic.ts`
- `useLeftoverDetailsLogic.ts`
- `useLeftoverFormLogic.ts`

### Other Notable Files
- **Apollo Client:** `lib/apolloClient.ts`
- **Theme Config:** `lib/themeConfig.ts`
- **Types:** `types/leftover.types.ts`

## Decisions/Assumptions
- Test plans will be created for each major component and custom hook listed above.
- Only client-side code is in scope for this plan.

## Next Steps
- Proceed to Task 1.2: Document Jest setup and configuration for the client.
