# Jest Best Practices for Vite + React Projects

**Date:** 2025-05-14

## Research Summary
- Vite projects use ESM by default, but Jest is CJS-first. `ts-jest` is the most stable for TypeScript + Jest in Vite projects, but ESM support is still experimental in Jest.
- For best compatibility, keep Jest config and test files in CJS/TS (not ESM) and avoid ESM-only imports in tests.
- Use `@testing-library/react` and `@testing-library/user-event` for React component and user interaction testing.
- Use `@testing-library/jest-dom` for custom matchers.
- Place setup files in `src/__tests__/jest.setup.ts` and reference in `setupFilesAfterEnv`.
- Use `testEnvironment: 'jsdom'` for React DOM tests.
- Place tests in `src/__tests__/` or as `*.test.tsx` next to components.
- Use `collectCoverage` and exclude types, setup, and test utility files from coverage.
- Add `clearMocks`, `resetMocks`, and `restoreMocks` for test isolation.
- Add `transformIgnorePatterns` for node_modules ESM compatibility if needed.
- Add `moduleDirectories: ['node_modules', 'src']` for absolute imports.

## Updated Jest Configuration Recommendation
Create `/client/jest.config.ts`:
```ts
import type { Config } from 'jest';

const config: Config = {
  preset: 'ts-jest',
  testEnvironment: 'jsdom',
  roots: ['<rootDir>/src'],
  testMatch: ['**/__tests__/**/*.test.(ts|tsx)', '**/?(*.)+(spec|test).[tj]s?(x)'],
  setupFilesAfterEnv: ['<rootDir>/src/__tests__/jest.setup.ts'],
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/$1',
  },
  moduleDirectories: ['node_modules', 'src'],
  collectCoverage: true,
  collectCoverageFrom: ['src/**/*.{ts,tsx}', '!src/__tests__/**', '!src/types/**'],
  coverageDirectory: 'coverage',
  coverageReporters: ['text', 'lcov', 'clover'],
  clearMocks: true,
  resetMocks: true,
  restoreMocks: true,
  // Uncomment if you see ESM transform errors:
  // transformIgnorePatterns: [
  //   '/node_modules/(?!(your-esm-package)/)'
  // ],
};

export default config;
```

## Additional Best Practices
- Use `describe`/`it` blocks for test structure.
- Use `beforeEach`/`afterEach` for setup/cleanup.
- Mock network requests and external dependencies.
- Prefer RTL queries by role/text/label over test IDs.
- Use `user-event` for simulating user actions.
- Keep tests isolated and avoid global state.
- Document how to run tests in the README.

---
**This configuration and approach follows current best practices for Jest in Vite + React projects as of May 2025.**
